#include <stdio.h>
#include <string.h>

int main()
{
    char original[1000], Copy[1000];

    printf("Input a string\n");
    gets(source);

    strcpy(Copy, original);

    printf("original string: %s\n", original);
    printf("Copy string: %s\n", Copy);

    return 0;
}
